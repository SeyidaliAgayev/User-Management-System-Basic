package service.impl;

import enums.Exceptions;
import exception.UserNotFoundException;
import globalData.GlobalData;
import model.User;
import service.UserService;
import util.InputUtil;

import java.time.LocalDate;
import static helper.UserServiceHelper.fillUser;
import static helper.UserServiceHelper.findById;
import static helper.UserServiceHelper.deleteById;

public class UserServiceImpl implements UserService {
    @Override
    public void register() {
        int userCount = InputUtil.inputRequiredInt("How many user will be register: ");

        if (GlobalData.users == null) {
            GlobalData.users = new User[userCount];
            for (int i = 0; i < GlobalData.users.length; i++) {
                GlobalData.users[i] = fillUser();
            }
        } else {
            User[] tempUser = GlobalData.users;
            GlobalData.users = new User[GlobalData.users.length + userCount];
            for (int i = 0; i < tempUser.length; i++) {
                GlobalData.users[i] = tempUser[i];
            }
            for (int i = tempUser.length; i < GlobalData.users.length; i++) {
                GlobalData.users[i] = fillUser();
            }
            System.out.println("User has been registered successfully!");
        }
    }

    @Override
    public void show() {
        System.out.println("----------------------User List----------------------");
        if (GlobalData.users != null) {
            for (int i = 0; i < GlobalData.users.length; i++) {
                System.out.println(GlobalData.users[i].toString());
            }
        } else {
            System.out.println("---------------------\n" +
                    "User has not yet!\n" +
                    "---------------------");
        }
    }

    @Override
    public void update() {
        int id = InputUtil.inputRequiredInt("Which user do you want to update: ");
        for (int i = 0; i < GlobalData.users.length; i++) {
            if (GlobalData.users[i].getId() == id) {
                System.out.println("Note: If you don't want to change selected field just press enter!");
                String name = InputUtil.inputRequiredString("Name: ");
                if (name.equals("")) {

                } else {
                    GlobalData.users[i].setName(name);
                }
                String surname = InputUtil.inputRequiredString("Surname: ");
                if (surname.equals("")) {

                } else {
                    GlobalData.users[i].setSurname(surname);
                }
                LocalDate birthday = null;
                String birthdayInput = InputUtil.inputRequiredDate("Birthday: ");
                if (!birthdayInput.isEmpty()) {
                    birthday = LocalDate.parse(birthdayInput);
                }
                GlobalData.users[i].setBirthday(birthday);
//                if (birthday.equals("")) {
//
//                } else {
//                    GlobalData.users[i].setBirthday(birthday);
//                }
//                LocalDate registerDate = LocalDate.parse(InputUtil.inputRequiredDate("Register Date: "));
//                if (registerDate.equals("")) {
//
//                } else {
//                    GlobalData.users[i].setRegisterDate(registerDate);
//                }
//                LocalDate updateDate = LocalDate.parse(InputUtil.inputRequiredDate("Update Date: "));
//                if (updateDate.equals("")) {
//
//                } else {
//                    GlobalData.users[i].setUpdateDate(updateDate);
//                }
            } else {
                throw new UserNotFoundException(Exceptions.User_Not_Found);
            }
        }
    }

    @Override
    public void delete() {
        int id = 0;
        User user = deleteById();
        user.toString();

        User[] tempUser = GlobalData.users;
        GlobalData.users = new User[GlobalData.users.length - 1];

        for (int i = 0; i < GlobalData.users.length; i++) {
            if (tempUser[i].getId() < user.getId()) {
                GlobalData.users[i] = tempUser[i];
            } else {
                GlobalData.users[i] = tempUser[i+1];
            }
            System.out.println("User had been deleted successfully!" + GlobalData.users[i]);
        }
    }
    @Override
        public void search () {
            String key = InputUtil.inputRequiredString("Search user by (name/surname): ");
            boolean isFind = false;

            for (int i = 0; i < GlobalData.users.length; i++) {
                if (GlobalData.users[i].getName().contains(key) ||
                        GlobalData.users[i].getSurname().contains(key)) {
                    isFind = true;
                    System.out.println(GlobalData.users[i].toString());
                }
            }
            if (!isFind) {
                throw new UserNotFoundException(Exceptions.User_Not_Found);
            }
        }
    }
