package globalData;

import model.User;

public class GlobalData {
    public static User[] users;
}
