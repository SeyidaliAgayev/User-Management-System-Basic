package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class User {
    private Long id;
    private String name;
    private String surname;
    private LocalDate birthday;
//    private LocalDate registerDate;
//    private LocalDate updateDate;

    public User(Long id, String name, String surname, LocalDate birthday) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.birthday = birthday;
//        this.registerDate = registerDate;
//        this.updateDate = updateDate;
    }
    public User() {

    }


    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

//    public LocalDate getRegisterDate() {
//        return getRegisterDate();
//    }
//
//    public void setRegisterDate(LocalDate registerDate) {
//        this.registerDate = registerDate;
//    }
//
//    public LocalDate getUpdateDate() {
//        return getUpdateDate();
//    }
//
//    public void setUpdateDate(LocalDate updateDate) {
//        this.updateDate = updateDate;
//    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + getId() +
                ", name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", birthday=" + birthday +
//                ", registerDate=" + registerDate +
//                ", updateDate=" + updateDate +
                '}';
    }
}
