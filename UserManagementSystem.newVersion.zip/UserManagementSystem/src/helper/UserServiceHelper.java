package helper;

import enums.Exceptions;
import exception.UserNotFoundException;
import exception.WrongFormatException;
import globalData.GlobalData;
import model.User;
import util.InputUtil;

import java.time.LocalDate;

import static util.InputUtil.*;

public class UserServiceHelper {
    public static User fillUser() {
        try {
            int id = inputRequiredInt("Enter the ID: ");
            String name = inputRequiredString("Enter the name: ");
            String surname = inputRequiredString("Enter the surname: ");
            LocalDate birthday = birthdayHelperService();
//            LocalDate registerDate = LocalDate.now();
//            LocalDate updateDate = LocalDate.now();
            return new User((long) id, name, surname, birthday );
        } catch (WrongFormatException ex) {
            System.out.println(ex.getMessage());
            return null;
        }

    }

    public static User findById(int id) {
        User user = new User();
        if (GlobalData.users == null) {
            System.out.println("-----------------------\n" +
                    "User doesn't exist!\n" +
                    "-----------------------");
        } else {
            System.out.println("Note: If you don't want to change selected field just press enter!");
            for (int i = 0; i < GlobalData.users.length; i++) {
                if (GlobalData.users[i].getId() == id) {
                    user = GlobalData.users[i];
                    break;
                } else {
                    throw new UserNotFoundException(Exceptions.User_Not_Found);
                }
            }
        }
        return user;
    }
    public static User deleteById() {
        User user = new User();
        if (GlobalData.users == null) {
            System.out.println("-------------------\n" +
                    "User has not yet!\n" +
                    "----------------------");
        } else {
            int id = InputUtil.inputRequiredInt("Which user do you want to delete: ");
            for (int i = 0; i < GlobalData.users.length; i++) {
                if (GlobalData.users[i].getId() == id) {
                    user = GlobalData.users[i];
                    break;
                }
            }
        }
        return user;
    }

    public static LocalDate birthdayHelperService() {
        String str1 = inputRequiredString("Enter the Birth Date(day-month-years): ");
        String[] str2 = str1.split("-");
        int day = Integer.parseInt(str2[0]);
        int month = Integer.parseInt(str2[1]);
        int years = Integer.parseInt(str2[2]);
        return LocalDate.of(day, month, years);
    }

//    public static LocalDate registerDateHelperService() {
//        String str1 = inputRequiredString("Enter the Register Date(day-month-years): ");
//        String[] str2 = str1.split("-");
//        int day = Integer.parseInt(str2[0]);
//        int month = Integer.parseInt(str2[1]);
//        int years = Integer.parseInt(str2[2]);
//        return LocalDate.of(day, month, years);
//    }
//    public static LocalDate updateDateHelperService() {
//        String str1 = inputRequiredString("Enter the Update Date(day-month-years): ");
//        String[] str2 = str1.split("-");
//        int day = Integer.parseInt(str2[0]);
//        int month = Integer.parseInt(str2[1]);
//        int years = Integer.parseInt(str2[2]);
//        return LocalDate.of(day, month, years);
//    }
}

