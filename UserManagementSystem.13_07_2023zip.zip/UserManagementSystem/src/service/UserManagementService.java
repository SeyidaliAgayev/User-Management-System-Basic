package service;

public interface UserManagementService {
    void managament();
}
