package service;


public interface UserService {
    boolean register();
    void show();
    boolean update();
    boolean delete();
    void search();
}
