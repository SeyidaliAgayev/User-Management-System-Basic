package service;


public interface UserService {
    void register();
    void show();
    void update();
    void delete();
    void search();
}
