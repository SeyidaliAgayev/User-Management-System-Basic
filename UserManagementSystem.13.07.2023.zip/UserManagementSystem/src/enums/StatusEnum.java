package enums;

public enum StatusEnum {
    REGISTER_SUCCESSFULLY,
    UPDATE_SUCCESSFULLY,
    DELETE_SUCCESSFULLY,
}
